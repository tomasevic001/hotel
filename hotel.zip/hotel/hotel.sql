-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2020 at 11:39 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cvetkovic`
--

-- --------------------------------------------------------

--
-- Table structure for table `kontakti`
--

CREATE TABLE `kontakti` (
  `soba` varchar(50) NOT NULL,
  `imeprezime` varchar(255) NOT NULL,
  `tel` int(11) NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kontakti`
--

INSERT INTO `kontakti` (`soba`, `imeprezime`, `tel`, `ID`) VALUES
('Panorama', 'test', 0, 1),
('Crazy Time', 'test', 1232312, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pitanja`
--

CREATE TABLE `pitanja` (
  `ID` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `naslov` varchar(255) NOT NULL,
  `dodInfo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pitanja`
--

INSERT INTO `pitanja` (`ID`, `ime`, `prezime`, `email`, `naslov`, `dodInfo`) VALUES
(1, 'Aleksandar Cvetkovic', '', 'a.cvetkovicks@gmail.com', '', 'Test kontakt forme');

-- --------------------------------------------------------

--
-- Table structure for table `registrovani`
--

CREATE TABLE `registrovani` (
  `ID` int(11) NOT NULL,
  `ime` varchar(255) DEFAULT NULL,
  `prezime` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `vrsta` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `registrovani`
--

INSERT INTO `registrovani` (`ID`, `ime`, `prezime`, `username`, `email`, `password`, `vrsta`) VALUES
(1, 'Aleksandar', 'Cvetkovic', 'aleksandar', 'aleksandar.cvks@gmail.com', 'alex', 'AD'),
(2, 'Korisnik', 'Korisnik', 'korisnik', 'korisnik@korisnik.com', 'alex', 'KO'),
(3, 'Marko', 'Milic', 'marko', 'marko@gmail.com', 'marko', 'KO'),
(4, 'Marija', 'Spanovic', 'marija', 'marija@gmail.com', 'marija', 'KO'),
(5, 'Tanja', 'Perovic', 'tanja', 'tanja@gmail.com', 'tanja', 'KO');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registrovani`
--
ALTER TABLE `registrovani`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registrovani`
--
ALTER TABLE `registrovani`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
